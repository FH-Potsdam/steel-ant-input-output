// getting started with p5js
function setup(){
}
function draw(){
}
